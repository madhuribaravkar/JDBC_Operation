import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class PreparedStatementSelect {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		PreparedStatement pstmt=con.prepareStatement(" select * from employee");
		ResultSet rs=pstmt.executeQuery();
		System.out.println("eno\tename\taddress\tsalary\tcid");
		System.out.println("--------------------------------------");
		
		while(rs.next()){
			System.out.println(rs.getInt("eno")+"\t"+rs.getString("ename")+"\t"+rs.getString("address")+"\t"+rs.getInt("salary")+"\t"+rs.getInt("cid"));
		}
	}

}
