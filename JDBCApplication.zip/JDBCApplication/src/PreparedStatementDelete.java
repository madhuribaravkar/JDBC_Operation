import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class PreparedStatementDelete {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		PreparedStatement pstmt=con.prepareStatement(" delete from address where oid=4");
		int row=pstmt.executeUpdate();
		System.out.println(row+"succesfully Delete");
		pstmt.close();
		con.close();
	}

}
