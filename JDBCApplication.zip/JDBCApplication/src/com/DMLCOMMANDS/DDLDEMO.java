package com.DMLCOMMANDS;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DDLDEMO {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
Class.forName("com.mysql.jdbc.Driver");
System.out.println("driver load successfully");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
System.out.println("connection create succesfully");
Statement stmt=con.createStatement();
System.out.println("statement object created");
//write sql query
String sql = "CREATE TABLE REGISTRATION " +
        "(id INTEGER not NULL, " +
        " first VARCHAR(255), " + 
        " last VARCHAR(255), " + 
        " age INTEGER, " + 
        " PRIMARY KEY(id ))"; 
//execute query
stmt.execute(sql);
System.out.println("table created successfully");
	
	}

}
