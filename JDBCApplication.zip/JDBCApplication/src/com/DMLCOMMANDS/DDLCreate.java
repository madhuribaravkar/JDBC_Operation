package com.DMLCOMMANDS;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DDLCreate {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
Class.forName("com.mysql.jdbc.Driver");
System.out.println("driver load sucessfully");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
System.out.println("connection sucessfuly");
Statement stmt=con.createStatement();
String sql="CREATE TABLE COURSE " +
        "(id INTEGER not NULL, " +
        " name VARCHAR(255), " + 
        " marks INTEGER, " + 
        " PRIMARY KEY(id ))"; 
stmt.execute(sql);
System.out.println("create table succesfully");
	}

}
