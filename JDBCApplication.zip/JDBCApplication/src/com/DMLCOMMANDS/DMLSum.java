package com.DMLCOMMANDS;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DMLSum {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		int sum=0;
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver load successfully");
		//Connection
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("Sum DML Commands");
		String
		sql="select * from employee where salary=(select sum(salary) from employee)";
		
		ResultSet rs;
		rs=stmt.executeQuery(sql);
		while(rs.next()){
			int s=rs.getInt(1);
			sum=sum+s;
			String str=Integer.toString(sum);
			}
		
				
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


	}

}
