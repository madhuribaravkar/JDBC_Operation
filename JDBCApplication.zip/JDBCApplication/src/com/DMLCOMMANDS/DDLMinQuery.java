package com.DMLCOMMANDS;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DDLMinQuery {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver load successfully");
		//Connection
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("Maximum Salary:");
		String
				//sql="update customer set name='monu' where cid=2";
		//sql="delete from address where oid=2";
		sql="select * from employee where salary=(select min(salary) from employee)";
		ResultSet rs;		
		rs=stmt.executeQuery(sql);
		System.out.println("eno\tename\taddress\tsalary\tcid");
		System.out.println("--------------------------------------");
		while(rs.next()){
			System.out.println(rs.getString("eno")+"\t"+rs.getString("ename")+"\t"+rs.getString("address")+"\t"+rs.getString("salary")+"\t"+rs.getString("cid"));
		}
				
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

}
