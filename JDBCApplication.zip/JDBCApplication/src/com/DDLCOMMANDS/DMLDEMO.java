package com.DDLCOMMANDS;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DMLDEMO {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
Class.forName("com.mysql.jdbc.Driver");
System.out.println("driver load successfully");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
System.out.println("connection create succesfully");
Statement stmt=con.createStatement();
System.out.println("statement object created");
ResultSet rs;

rs = stmt.executeQuery("SELECT name FROM customer WHERE cid = 2");
while ( rs.next() ) {
    String lastName = rs.getString("name");
    System.out.println(lastName);
}
con.close();
	}

}
