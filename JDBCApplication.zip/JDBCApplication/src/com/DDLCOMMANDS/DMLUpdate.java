package com.DDLCOMMANDS;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DMLUpdate {
	public static void main(String[] args) throws ClassNotFoundException {
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("driver load succesfully");
	try {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("statement object created");
		String sql="update customer set name='kaju' where cid=1";
		stmt.executeUpdate(sql);
		
		System.out.println("Update record succesfully");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

}
