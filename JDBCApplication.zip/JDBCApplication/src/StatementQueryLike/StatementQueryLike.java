package StatementQueryLike;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class StatementQueryLike {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver load successfully");
		//Connection
		Connection con;
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("statement object created");
		String sql="select cid,name,age from customer"+
				 " WHERE  name LIKE '%a%'";
		ResultSet rs=stmt.executeQuery(sql);
		System.out.println("cid\tname\tage");
		System.out.println("-------------------------------------------");
		while(rs.next()){
		System.out.println(rs.getInt("cid")+"\t"+rs.getString("name")+"\t"+rs.getInt("age"));
		}
	}
}
