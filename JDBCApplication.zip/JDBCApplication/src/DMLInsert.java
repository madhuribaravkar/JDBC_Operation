import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class DMLInsert {
	//public static final String URL="jdbc:mysql://localhost:3306/info";
	//public static final String USER_NAME="root";
	//public static final String PASSWORD="";
	
	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		//step1: load Driver
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver load successfully");
		//Connection
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("Inserting records into the table....");
		String sql="insert into customer values(12,'ajju',34)";
		stmt.executeUpdate(sql);	
		System.out.println("Insert records successfully...!");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		

	}

}
