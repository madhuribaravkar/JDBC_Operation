import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class PreparedStatementLike {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		PreparedStatement pstmt=con.prepareStatement("select cid,name,age from customer"+
				 " WHERE  name LIKE '%a%'");
		ResultSet rs=pstmt.executeQuery();
		
		System.out.println("cid\tname\tage");
		System.out.println("-------------------------------------------");
		while(rs.next()){
			System.out.println(rs.getInt("cid")+"\t"+rs.getString("name")+"\t"+rs.getInt("age"));
		}
	}

}
