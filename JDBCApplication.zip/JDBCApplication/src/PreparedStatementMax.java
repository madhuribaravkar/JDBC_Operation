import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class PreparedStatementMax {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver load successfully");
		//Connection
		Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("Maximum Salary:");
		PreparedStatement pstmt=con.prepareStatement("select * from employee where salary=(select max(salary) from employee)");
		//PreparedStatement pstmt=con.prepareStatement("select * from employee where salary=(select min(salary) from employee)");
		//PreparedStatement pstmt=con.prepareStatement("select * from employee where salary=(select sum(salary) from employee)");
		ResultSet rs;		
		rs=pstmt.executeQuery();
		System.out.println("eno\tename\taddress\tsalary\tcid");
		System.out.println("--------------------------------------");
		while(rs.next()){
			System.out.println(rs.getString("eno")+"\t"+rs.getString("ename")+"\t"+rs.getString("address")+"\t"+rs.getString("salary")+"\t"+rs.getString("cid"));
		}
				
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

		}
}
