import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class preparedStatementInsert {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
Scanner sn=new Scanner(System.in);
System.out.println("enter your cid:");
int cid=sn.nextInt();
System.out.println("enter your name:");
String name=sn.next();
System.out.println("enter your age:");
int age=sn.nextInt();
PreparedStatement pstmt=con.prepareStatement("insert into customer values(?,?,?)");
pstmt.setInt(1,cid);
pstmt.setString(2,name);
pstmt.setInt(3, age);
int row=pstmt.executeUpdate();
System.out.println(row+"row affected");
pstmt.close();
con.close();
	}

}
