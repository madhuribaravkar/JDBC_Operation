import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
public class PreparedStatementDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		  
		PreparedStatement ps=con.prepareStatement("insert into customer values(?,?,?)");  
		  
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
		  
		do{  
		System.out.println("enter cid:");  
		int cid=Integer.parseInt(br.readLine());  
		System.out.println("enter name:");  
		String name=br.readLine();  
		System.out.println("enter age:");  
		int age=Integer.parseInt(br.readLine());  
		  
		ps.setInt(1,cid);  
		ps.setString(2,name);  
		ps.setFloat(3,age);  
		int i=ps.executeUpdate();  
		System.out.println(i+" records affected");  
		  
		System.out.println("Do you want to continue: y/n");  
		String s=br.readLine();  
		if(s.startsWith("n")){  
		break;  
		}  
		}while(true);  
		  
		con.close();  
		  
	}

}
