import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DQLdemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("driver load successfully");
		//Connection
		Connection con;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/info","root","");
		
		System.out.println("connection create succesfully");
		Statement stmt=con.createStatement();
		System.out.println("statement object created");
		String sql="select * from customer";
		ResultSet rs=stmt.executeQuery(sql);
		System.out.println("cid\tname\tage");
		while(rs.next()){
		System.out.println(rs.getString("cid")+"\t"+rs.getString("name")+"\t"+rs.getString("age"));
		}
	}

}
